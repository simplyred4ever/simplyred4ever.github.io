﻿var testdata2=

[
  {
    "id": "1",
    "startTime": "2014/4/5",
    "endTime": "2014/4/11",
    "title": "Project 1",
    "content": "<b>description 1</b>"
  },
  {
    "id": "2",
    "startTime": "2014/4/1",
    "endTime": "2015/11/3",
    "title": "Project 2",
    "content": "<b>description 2</b>"
  }
]